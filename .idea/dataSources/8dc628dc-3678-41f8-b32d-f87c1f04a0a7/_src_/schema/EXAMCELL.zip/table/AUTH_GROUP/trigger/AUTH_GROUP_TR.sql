create trigger AUTH_GROUP_TR
	before insert
	on AUTH_GROUP
	for each row
BEGIN
        SELECT "AUTH_GROUP_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
