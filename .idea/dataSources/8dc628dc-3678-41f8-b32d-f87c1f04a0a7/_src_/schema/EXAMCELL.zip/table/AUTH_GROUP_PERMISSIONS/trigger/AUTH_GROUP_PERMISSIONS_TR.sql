create trigger AUTH_GROUP_PERMISSIONS_TR
	before insert
	on AUTH_GROUP_PERMISSIONS
	for each row
BEGIN
        SELECT "AUTH_GROUP_PERMISSIONS_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
