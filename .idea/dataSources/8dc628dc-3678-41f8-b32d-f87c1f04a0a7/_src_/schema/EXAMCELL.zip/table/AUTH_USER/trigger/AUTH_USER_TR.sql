create trigger AUTH_USER_TR
	before insert
	on AUTH_USER
	for each row
BEGIN
        SELECT "AUTH_USER_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
