create trigger AUTH_USER_GROUPS_TR
	before insert
	on AUTH_USER_GROUPS
	for each row
BEGIN
        SELECT "AUTH_USER_GROUPS_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
