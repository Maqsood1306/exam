create trigger AUTH_USER_USER_PERMISSIONS_TR
	before insert
	on AUTH_USER_USER_PERMISSIONS
	for each row
BEGIN
        SELECT "AUTH_USER_USER_PERMISSIONS_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
