create trigger DJANGO_ADMIN_LOG_TR
	before insert
	on DJANGO_ADMIN_LOG
	for each row
BEGIN
        SELECT "DJANGO_ADMIN_LOG_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
