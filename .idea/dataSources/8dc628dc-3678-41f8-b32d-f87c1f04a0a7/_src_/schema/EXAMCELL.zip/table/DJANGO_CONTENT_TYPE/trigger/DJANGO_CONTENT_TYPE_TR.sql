create trigger DJANGO_CONTENT_TYPE_TR
	before insert
	on DJANGO_CONTENT_TYPE
	for each row
BEGIN
        SELECT "DJANGO_CONTENT_TYPE_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
