create trigger EXAMCELL_RESULT_TR
	before insert
	on EXAMCELL_RESULT
	for each row
BEGIN
        SELECT "EXAMCELL_RESULT_SQ".nextval
        INTO :new."ID" FROM dual;
    END;
